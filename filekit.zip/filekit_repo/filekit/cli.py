"""
FileKit CLI - A handy file utility tool.
Usage: python -m filekit <command> [args]
"""

import os
import sys
import shutil
import hashlib
import argparse
from pathlib import Path


def file_info(path: str) -> None:
    """Print detailed info about a file."""
    p = Path(path)
    if not p.exists():
        print(f"Error: '{path}' does not exist.")
        sys.exit(1)

    stat = p.stat()
    size = stat.st_size
    units = ["B", "KB", "MB", "GB"]
    for unit in units:
        if size < 1024:
            break
        size /= 1024
    size_str = f"{size:.2f} {unit}"

    print(f"Name      : {p.name}")
    print(f"Path      : {p.resolve()}")
    print(f"Type      : {'Directory' if p.is_dir() else 'File'}")
    print(f"Size      : {size_str}")
    print(f"Extension : {p.suffix or 'None'}")
    print(f"Modified  : {__import__('datetime').datetime.fromtimestamp(stat.st_mtime)}")


def checksum(path: str, algorithm: str = "sha256") -> None:
    """Compute the checksum of a file."""
    p = Path(path)
    if not p.is_file():
        print(f"Error: '{path}' is not a file.")
        sys.exit(1)

    h = hashlib.new(algorithm)
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)

    print(f"{algorithm.upper()} ({p.name}): {h.hexdigest()}")


def rename_bulk(directory: str, prefix: str = "", suffix: str = "", extension: str = "") -> None:
    """Bulk rename files in a directory."""
    d = Path(directory)
    if not d.is_dir():
        print(f"Error: '{directory}' is not a directory.")
        sys.exit(1)

    files = [f for f in d.iterdir() if f.is_file()]
    if not files:
        print("No files found in directory.")
        return

    renamed = 0
    for i, f in enumerate(sorted(files), start=1):
        stem = f"{prefix}{f.stem}{suffix}" if (prefix or suffix) else f.stem
        ext = extension if extension else f.suffix
        if not ext.startswith(".") and ext:
            ext = f".{ext}"
        new_name = d / f"{stem}{ext}"
        if new_name != f:
            f.rename(new_name)
            print(f"  {f.name} → {new_name.name}")
            renamed += 1

    print(f"\nDone. {renamed} file(s) renamed.")


def find_duplicates(directory: str) -> None:
    """Find duplicate files in a directory by checksum."""
    d = Path(directory)
    if not d.is_dir():
        print(f"Error: '{directory}' is not a directory.")
        sys.exit(1)

    seen = {}
    for f in d.rglob("*"):
        if not f.is_file():
            continue
        h = hashlib.md5()
        with open(f, "rb") as fh:
            for chunk in iter(lambda: fh.read(8192), b""):
                h.update(chunk)
        digest = h.hexdigest()
        seen.setdefault(digest, []).append(f)

    duplicates = {k: v for k, v in seen.items() if len(v) > 1}
    if not duplicates:
        print("No duplicates found.")
        return

    print(f"Found {len(duplicates)} group(s) of duplicates:\n")
    for digest, files in duplicates.items():
        print(f"  [{digest[:10]}...]")
        for f in files:
            print(f"    {f}")


def main():
    parser = argparse.ArgumentParser(
        prog="filekit",
        description="FileKit — a small but handy file utility."
    )
    sub = parser.add_subparsers(dest="command", required=True)

    # info
    p_info = sub.add_parser("info", help="Show file info")
    p_info.add_argument("path", help="Path to file or directory")

    # checksum
    p_sum = sub.add_parser("checksum", help="Compute file checksum")
    p_sum.add_argument("path", help="Path to file")
    p_sum.add_argument("--algo", default="sha256", choices=["md5", "sha1", "sha256", "sha512"])

    # rename
    p_ren = sub.add_parser("rename", help="Bulk rename files")
    p_ren.add_argument("directory", help="Target directory")
    p_ren.add_argument("--prefix", default="", help="Add prefix to filenames")
    p_ren.add_argument("--suffix", default="", help="Add suffix to filenames")
    p_ren.add_argument("--ext", default="", help="Change extension for all files")

    # duplicates
    p_dup = sub.add_parser("dupes", help="Find duplicate files")
    p_dup.add_argument("directory", help="Directory to scan")

    args = parser.parse_args()

    if args.command == "info":
        file_info(args.path)
    elif args.command == "checksum":
        checksum(args.path, args.algo)
    elif args.command == "rename":
        rename_bulk(args.directory, args.prefix, args.suffix, args.ext)
    elif args.command == "dupes":
        find_duplicates(args.directory)


if __name__ == "__main__":
    main()
