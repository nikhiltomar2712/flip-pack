"""FileKit - A handy file utility CLI."""

__version__ = "0.1.0"
__author__ = "Your Name"
