from filekit.cli import main

main()
