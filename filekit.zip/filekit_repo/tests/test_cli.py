"""Tests for FileKit."""

import os
import pytest
from pathlib import Path
from filekit.cli import file_info, checksum, rename_bulk, find_duplicates


def test_file_info(tmp_path, capsys):
    f = tmp_path / "hello.txt"
    f.write_text("Hello, World!")
    file_info(str(f))
    out = capsys.readouterr().out
    assert "hello.txt" in out
    assert "File" in out


def test_checksum(tmp_path, capsys):
    f = tmp_path / "data.txt"
    f.write_text("test content")
    checksum(str(f), "sha256")
    out = capsys.readouterr().out
    assert "SHA256" in out
    assert "data.txt" in out


def test_rename_bulk_prefix(tmp_path, capsys):
    for name in ["a.txt", "b.txt", "c.txt"]:
        (tmp_path / name).write_text("x")
    rename_bulk(str(tmp_path), prefix="new_")
    files = {f.name for f in tmp_path.iterdir()}
    assert "new_a.txt" in files
    assert "new_b.txt" in files


def test_find_duplicates(tmp_path, capsys):
    content = "same content"
    (tmp_path / "file1.txt").write_text(content)
    (tmp_path / "file2.txt").write_text(content)
    (tmp_path / "unique.txt").write_text("different")
    find_duplicates(str(tmp_path))
    out = capsys.readouterr().out
    assert "1 group" in out
