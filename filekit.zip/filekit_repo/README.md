# 🗂️ FileKit

A small, handy Python CLI for common file operations — no dependencies, just Python 3.8+.

## Features

| Command | What it does |
|---------|-------------|
| `info` | Show name, size, type, modified date for any file or folder |
| `checksum` | Compute MD5 / SHA1 / SHA256 / SHA512 hash of a file |
| `rename` | Bulk rename files with a prefix, suffix, or extension change |
| `dupes` | Find duplicate files in a directory by content hash |

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/filekit.git
cd filekit
pip install -e .
```

## Usage

```bash
# File info
filekit info myfile.pdf

# Checksum
filekit checksum myfile.pdf --algo sha256

# Bulk rename — add a prefix
filekit rename ./photos --prefix "2024_"

# Bulk rename — change extension
filekit rename ./docs --ext md

# Find duplicates
filekit dupes ./downloads
```

## Running Tests

```bash
pip install pytest
pytest
```

## Contributing

Contributions are welcome! Please open an issue or submit a pull request.

1. Fork the repo
2. Create a branch: `git checkout -b feature/my-feature`
3. Commit your changes: `git commit -m "Add my feature"`
4. Push and open a PR

## License

MIT
